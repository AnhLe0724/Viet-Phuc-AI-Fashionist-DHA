<div align="center">
<h1>Mobile-VTON: High-Fidelity On-Device Virtual Try-On (CVPR 2026)</h1>

<a href='https://zhenchenwan.github.io/Mobile-VTON/'><img src='https://img.shields.io/badge/Project-Page-green'></a>
<a href='https://arxiv.org/abs/2603.00947'><img src='https://img.shields.io/badge/Paper-Arxiv-red'></a>
<a href='https://huggingface.co/FlashStight/Mobile-VTON'><img src='https://img.shields.io/badge/%F0%9F%A4%97%20Hugging%20Face-Model-blue'></a>


</div>

This is the official implementation of the paper ["Mobile-VTON: High-Fidelity On-Device Virtual Try-On"](https://arxiv.org/abs/2603.00947).

Star ⭐ us if you like it!


---


![teaser](assets/teaser.jpg)&nbsp;


## Requirements

```
git clone https://github.com/tmllab/2026_CVPR_Mobile-VTON.git
cd 2026_CVPR_Mobile-VTON

conda env create -f environment.yaml
conda activate mobile
```


## Data preparation

### VITON-HD
You can download VITON-HD dataset from [VITON-HD](https://github.com/shadow2496/VITON-HD).

After download VITON-HD dataset, move txt_files/image_descriptions.txt file into the test folder, and move vitonhd_train_tagged.json into the train folder.

Structure of the Dataset directory should be as follows.

```

test
|-- image
|-- image-densepose
|-- agnostic-mask
|-- cloth
|-- image_descriptions.txt
|-- ...

```

### DressCode
You can download DressCode dataset from [DressCode](https://github.com/aimagelab/dress-code).

IDM-VTON provide pre-computed densepose images and captions for garments [here](https://kaistackr-my.sharepoint.com/:u:/g/personal/cpis7_kaist_ac_kr/EaIPRG-aiRRIopz9i002FOwBDa-0-BHUKVZ7Ia5yAVVG3A?e=YxkAip).

After download the DressCode dataset, place image-densepose directories and txt_files/dc_descriptions.txt files as follows.

```
DressCode
|-- upper_body
    |-- images
    |-- image-densepose
    |-- dc_descriptions.txt
    |-- ...
```


## Inference

VITON-HD and DressCode inference scripts are shown in the inference.sh

## Acknowledgements


Thanks [IP-Adapter](https://github.com/tencent-ailab/IP-Adapter) for base codes.

Thanks [IDM-VTON](https://github.com/yisol/IDM-VTON.git) for densepose of DressCode dataset.

## Citation
```
@article{wan2026mobile,
  title={Mobile-VTON: High-Fidelity On-Device Virtual Try-On},
  author={Wan, Zhenchen and Chen, Ce and Lin, Runqi and Huang, Jiaxin and Chen, Tianxi and Xu, Yanwu and Liu, Tongliang and Gong, Mingming},
  journal={arXiv e-prints},
  pages={arXiv--2603},
  year={2026}
}
```


## License
The codes and checkpoints in this repository are under the [CC BY-NC-SA 4.0 license](https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode).
